def sentence(comp_sen):
    final_output=[]
    comp_sen=comp_sen.split(".")
    for sen in comp_sen:
        sen=sen.strip()
        if len(sen)==0:
            continue
        sen=sen.split()
        new_words=[]
        excluded_words=["is","in","a"]
        for i in range(len(sen)):
            if i==0:
                new_words.append(sen[i].capitalize())
            elif sen[i] in excluded_words:
                new_words.append(sen[i].lower())
            else:
                new_words.append(sen[i].capitalize())
        final_output.append(" ".join(new_words))
    print(". ".join(final_output))
ready=input("ready to play? ").lower().strip()
while ready.startswith("y"):
    comp_sen=input("enter a sentence: ")
    sentence(comp_sen)
    ready=input("try again? ").lower().strip()

    